<?php $__env->startSection('content'); ?>

    <?php if(session()->has('message')): ?>
        <div
            id="show-message"
            class="alert alert-success alert-dismissible text-center">
            <button
                type="button"
                class="close"
                data-dismiss="alert"
                aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">

                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-4">
                                <h4 class="font-weight-bold"> Idea List</h4>
                            </div>

                            <div id="stopwatch" style="font-size: 20px; font-weight: bolder"
                                 class="col-md-4 justify-content-center align-content-center">

                            </div>

                            <div class="col-md-4 row justify-content-end align-items-end">
                                <a class="btn btn-primary" href="<?php echo e(route('ideas.create')); ?>">
                                    Add Idea
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body" id="reloaded_div">
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">Sl</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Idea</th>
                                <th scope="col">Status</th>
                                <th scope="col">Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $ideas ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="<?php echo e($idea->is_win === 1 ? 'bg-info' : ''); ?>">
                                    <th scope="row"><?php echo e(++$key); ?></th>
                                    <td><?php echo e($idea->name); ?></td>
                                    <td><?php echo e($idea->email); ?></td>
                                    <td><?php echo e($idea->idea); ?></td>
                                    <td>
                                        <?php if($idea->is_win === 0): ?>
                                            Loser
                                        <?php elseif($idea->is_win === 1): ?>
                                            Winner
                                        <?php elseif($idea->is_win === 2): ?>
                                            Player
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('ideas.destroy',$idea)); ?>" method="POST">

                                            <a class="btn btn-primary"
                                               href="<?php echo e(route('ideas.edit',$idea)); ?>">
                                                Edit
                                            </a>

                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button
                                                type="submit"
                                                onclick="return confirm('Are you sure?')"
                                                class="btn btn-danger">
                                                Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script>
        setTimeout(() => {
            let container = document.getElementById('show-message');
            if (container) {
                container.style.display = 'none';
            }

            let players = <?php echo json_encode($players, 15, 512) ?>;
            console.log(players.length);

            if (players.length) {
                startTimer();

            }

        }, 3000)


        let hr = 0;
        let min = 0;
        let sec = 0;
        let stoptime = true;

        function startTimer() {
            if (stoptime == true) {
                stoptime = false;
                timerCycle();
            }
        }

        function stopTimer() {
            if (stoptime == false) {
                stoptime = true;
            }
        }

        function timerCycle() {
            if (stoptime == false) {
                sec = parseInt(sec);
                min = parseInt(min);
                hr = parseInt(hr);

                sec = sec + 1;

                if (sec == 60) {
                    min = min + 1;
                    sec = 0;
                }
                if (min == 60) {
                    hr = hr + 1;
                    min = 0;
                    sec = 0;
                }

                if (sec < 10 || sec == 0) {
                    sec = '0' + sec;
                }
                if (min < 10 || min == 0) {
                    min = '0' + min;
                }
                if (hr < 10 || hr == 0) {
                    hr = '0' + hr;
                }

                document.getElementById("stopwatch").innerHTML = hr + ':' + min + ':' + sec;

                console.log(parseFloat(min));

                if (parseFloat(min) === 1) {
                    $("#reloaded_div").load(window.location.href + " #reloaded_div");
                } else if (parseFloat(min) === 2) {
                    $("#reloaded_div").load(window.location.href + " #reloaded_div");
                } else if (parseFloat(min) === 3) {
                    $("#reloaded_div").load(window.location.href + " #reloaded_div");
                    stopTimer();
                }

                setTimeout("timerCycle()", 1000);
            }
        }

        function resetTimer() {
            timer.innerHTML = '00:00:00';
        }

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/juyel/www/ITclan-BD-interview-task/itclan-assignment2/resources/views/ideas/index.blade.php ENDPATH**/ ?>