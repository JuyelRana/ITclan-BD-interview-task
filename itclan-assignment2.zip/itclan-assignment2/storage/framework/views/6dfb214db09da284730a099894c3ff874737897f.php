<!DOCTYPE html>
<html>
<head>
    <title>Successfully add an idea</title>
</head>
<body>

<center>
    <h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
        <a href="https://mjuyelrana.com/">Md Juyel Rana</a>
    </h2>
</center>

<p>Hi, <?php echo e($details['name']); ?></p>
<p>You have successfully added an idea to the idea list.</p>

<strong>Thank you very much. :)</strong>

</body>
</html>
<?php /**PATH /home/juyel/www/ITclan-BD-interview-task/itclan-assignment2/resources/views/emails/add_idea_email.blade.php ENDPATH**/ ?>