<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">

                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-md-4">
                                <h4 class="font-weight-bold">Article List</h4>
                            </div>

                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table article-list">
                                    <thead>
                                    <tr>
                                        <th scope="col">Sl</th>
                                        <th scope="col">Author</th>
                                        <th scope="col">Title</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Url</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Content</th>
                                        <th scope="col">Created At</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>

    <script>

        setTimeout(() => {
            $.get('https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=0b4c3b2699bf43ccbb8f807f7f6ef24d', function (response, status) {
                if (response.status === 'ok') {
                    let tableRows = response.articles.map((article, index) => {
                        return "<tr>"
                            + "<td>" + ++index + "</td>"
                            + "<td>" + article.author + "</td>"
                            + "<td>" + article.title + "</td>"
                            + "<td>" + article.description + "</td>"
                            + "<td>" + "<a href=" + article.url + " target=" + "_blank" + ">Click" + "<a/>" + "</td>"
                            + "<td>" + "<img src=" + article.urlToImage + " class=" + "img-fluid" + ">" + "</td>"
                            + "<td>" + article.content + "</td>"
                            + "<td>" + article.publishedAt + "</td>"
                            + "</tr>";
                    });
                    $("table.article-list tbody").append(tableRows);
                }
            });

        }, 1000)


    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/juyel/www/ITclan-BD-interview-task/itclan-assignment2/resources/views/articles/index.blade.php ENDPATH**/ ?>