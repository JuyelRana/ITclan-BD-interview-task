<!DOCTYPE html>
<html>
<head>
    <title>Congratulation {{ $details['name'] }}</title>
</head>
<body>

<center>
    <h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
        <a href="https://mjuyelrana.com/">Md Juyel Rana</a>
    </h2>
</center>

<p>Congratulation, {{ $details['name'] }}</p>
<p>{{ $details['msg'] }}.</p>

<strong>Good luck 😯</strong>

</body>
</html>
