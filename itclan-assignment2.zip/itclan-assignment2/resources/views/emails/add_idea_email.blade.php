<!DOCTYPE html>
<html>
<head>
    <title>Successfully add an idea</title>
</head>
<body>

<center>
    <h2 style="padding: 23px;background: #b3deb8a1;border-bottom: 6px green solid;">
        <a href="https://mjuyelrana.com/">Md Juyel Rana</a>
    </h2>
</center>

<p>Hi, {{ $details['name'] }}</p>
<p>You have successfully added an idea to the idea list.</p>

<strong>Thank you very much. :)</strong>

</body>
</html>
